<div class="card blue-grey darken-4">
    <div class="card-content white-text">
        <span class="card-title"></span>
        <h4>Hello World</h4>
        <p>Selamat Datang . . . !</p>
    </div>
    <div class="card-action">
        <a class="btn blue waves-effect waves-light" href="?p=Data">Mulai Mengelola Data</a>
    </div>
</div>